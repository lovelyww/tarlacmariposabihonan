<!DOCTYPE html>
<head>
    <title>Registration Form</title>
    <link rel="stylesheet" href="style2.css">
    <meta  name="viewport" content="=width=device-width, initial-scale=1.0">
</head>
<body>
    <div>
    <h1 class="logo">TARLAC MARIPOSA BIHONAN</h1>
</div>
    <div class="container">
        <div class="title">Sign up and Apply</div>
        <form action="process.php" method="post" novalidate>
            <div class="user-details">
                <div class="input-box">
                    <span class="details">First Name</span>
                    <input type="text" id="FirstName" name="FirstName" placeholder="Enter your First Name">
                </div>
                <div class="input-box">
                    <span class="details">Last Name</span>
                    <input type="text" id="LastName" name="LastName" placeholder="Enter your Last Name">
                </div>
                <div class="input-box">
                    <span class="details">Email</span>
                    <input type="email" id="email" name="email" placeholder="Create email">
                </div>
                <div class="input-box">
                    <span class="details">Password</span>
                    <input type="password" id="password" name="password" placeholder="Create Password">
                </div>
                <div class="input-box">
                    <span class="details">Confirm Password</span>
                    <input type="password" id="password_confirmation" name="password_confirmation" placeholder="Confirm Password">
                </div>
                <div class="input-box">
                    <span class="details">Age</span>
                    <input type="text" id="Age" name="Age" placeholder="Enter your Age">
                </div>
                <div class="input-box">
                    <span class="details">Contact No.</span>
                    <input type="text" id="ContactNo" name="ContactNo" placeholder="Enter your Contact No.">
                </div>
                <div class="input-box">
                    <span class="details">Address</span>
                    <input type="text" id="Address" name="Address" placeholder="Enter your Address">
                    </div>
                    <div class="input-box">
                        <span class="details">Position Applied For</span>
                    <select id="position" name="position">
                        <option value="productionworker">Production Worker</option>
                        </select>
                        </div>
                    <div  class="gender-details">
                        <input type="radio" name="Gender" id="dot-1">
                        <input type="radio" name="Gender" id="dot-2">
                        <span class="gender-title">Gender</span>
                        <div class="category">
                            <label for="dot-1">
                                <span class="dot one"></span>
                                <span class="gender">Male</span>
                            </label>
                            <label for="dot-2"> 
                                <span class="dot two"></span>
                                 <span class="gender">Female</span>
                            </label>
                        </div>
                    </div>
                    <button>Register</button>
                </form>
                </div>
            </div>
        </form>
    </div>
</body>